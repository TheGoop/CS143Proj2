insert into Review
Values ("Akshay", now(), 1317, 3.00, "Alright Movie.");